<?php include "header.php"?>

<!-- Slider -->
<!--//team-->
<div class="slider">
	<div class="callbacks_container">
		<ul class="rslides" id="slider">
			<li>
				<div class="w3layouts-banner-top w3layouts-banner-top1">
					<div class="container"> 
							<!-- <div class="slider-info">
								<h3>Why you need an advisor</h3>
								<h4>Being one of the biggest Equity Venture Fund consulting companies in the US, we will help you </h4>

							</div> -->
						</div>
					</div>
				</li>
				<li>
					<div class="w3layouts-banner-top">
						<div class="container">  
						</div>
					</div>
				</li>
				<li>
					<div class="w3layouts-banner-top3">
						<div class="container">  
						</div>
					</div>
				</li>
				<li>
					<div class="w3layouts-banner-top4">
						<div class="container">  
						</div>
					</div>
				</li>

			</ul>
		</div>
		<div class="clearfix"></div>
	</div>
	<!-- //Slider -->
	<!--team-->
	<div class="team">
		<div class="w3agile-spldishes">
			<div class="container">

				<div class="spldishes-grids">
					<!-- Owl-Carousel -->
					<div id="owl-demo" class="owl-carousel text-center agileinfo-gallery-row">
							<!-- <div class="item g1">
							   <img class="lazyOwl" src="images/10.png" style="width: 750px;height: 250px;" title="Our Team" alt=""/>
								<div class="agile-dish-caption">
									<h4>Jack Anderson</h4>
									<p>Porro</p>
									<span>Neque porro quisquam est qui dolorem Lorem ipsum dolor sit amet. </span>
									<ul class="top-links">
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
										<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
									</ul>
								</div>
							</div> -->
							<div class="item g1">
								<img class="lazyOwl" src="img/3.png" style="width: 250px;height: 200px;"  alt=""/>
							</div>
							<div class="item g1">
								<img class="lazyOwl" src="img/4.png" style="width: 250px;height: 200px;"  alt=""/>
							</div>
							<div class="item g1">
								<img class="lazyOwl" src="img/5.png" style="width: 250px;height: 200px;"  alt=""/>
							</div>
							<div class="item g1">
								<img class="lazyOwl" src="img/6.png" style="width: 250px;height: 200px;"  alt=""/>
							</div> 
							<div class="item g1">
								<img class="lazyOwl" src="img/7.png" style="width: 250px;height: 200px;"  alt=""/>
							</div> 
							<div class="item g1">
								<img class="lazyOwl" src="img/8.png" style="width: 250px;height: 200px;"  alt=""/>
							</div> 
							<div class="item g1">
								<img class="lazyOwl" src="img/9.png" style="width: 250px;height: 200px;"  alt=""/>
							</div> 
							<div class="item g1">
								<img class="lazyOwl" src="img/10.png" style="width: 250px;height: 200px;"  alt=""/>
							</div> 
							<div class="item g1">
								<img class="lazyOwl" src="img/11.png" style="width: 250px;height: 200px;"  alt=""/>
							</div> 
							<div class="item g1">
								<img class="lazyOwl" src="img/12.png" style="width: 250px;height: 200px;"  alt=""/>
							</div> 
							<div class="item g1">
								<img class="lazyOwl" src="img/13.png" style="width: 250px;height: 200px;"  alt=""/>
							</div> 
							<div class="item g1">
								<img class="lazyOwl" src="img/14.png" style="width: 250px;height: 200px;"  alt=""/>
							</div> 
							<div class="item g1">
								<img class="lazyOwl" src="img/15.png" style="width: 250px;height: 200px;"  alt=""/>
							</div> 
						</div> 
					</div> 
				</div>
			</div>
		</div>

		<!-- welcome -->
		<div class="welcome all_pad wthree">
			<div class="w3layouts-grids gal-wthree-agileits">
				<div class="container">
					<div id="jzBox" class="jzBox">
						<div id="jzBoxNextBig"></div>
						<div id="jzBoxPrevBig"></div>
						<img src="#" id="jzBoxTargetImg" alt=""/>
						<div id="jzBoxBottom">
							<div id="jzBoxTitle"></div>
							<div id="jzBoxMoreItems">
								<div id="jzBoxCounter"></div>
								<i class="arrow-left" id="jzBoxPrev"></i> 
								<i class="arrow-right" id="jzBoxNext"></i> 
							</div>
							<i class="close" id="jzBoxClose"></i>
						</div>
					</div>
					<div class="gallery-grids-row">
						<div class="col-md-3 gallery-grid">
							<div class="wpf-demo-4">  
								<a   class="jzBoxLink item-hover"  >  
									<img src="img/16.jpg" alt=" " class="img-responsive" />
								<!-- <div class="view-caption">
									<p>Full View</p>
								</div>  -->
							</a>    		
						</div>
					</div>
					<div class="col-md-3 gallery-grid">
						<div class="wpf-demo-4">  
							<a   class="jzBoxLink item-hover"  >  
								<img src="img/17.jpg" alt=" " class="img-responsive" /> 
							</a>    		
						</div>
					</div> 
					<div class="col-md-3 gallery-grid">
						<div class="wpf-demo-4">  
							<a   class="jzBoxLink item-hover"  >  
								<img src="img/18.jpg" alt=" " class="img-responsive" /> 
							</a>    		
						</div>
					</div>
					<div class="col-md-3 gallery-grid">
						<div class="wpf-demo-4">  
							<a   class="jzBoxLink item-hover"  >  
								<img src="img/19.jpg" alt=" " class="img-responsive" /> 
							</a>    		
						</div>
					</div>
					<div class="col-md-3 gallery-grid">
						<div class="wpf-demo-4">  
							<a   class="jzBoxLink item-hover"  >  
								<img src="img/20.jpg" alt=" " class="img-responsive" /> 
							</a>    		
						</div>
					</div>
					<div class="col-md-3 gallery-grid">
						<div class="wpf-demo-4">  
							<a   class="jzBoxLink item-hover"  >  
								<img src="img/21.jpg" alt=" " class="img-responsive" /> 
							</a>    		
						</div>
					</div>
					<div class="col-md-3 gallery-grid">
						<div class="wpf-demo-4">  
							<a   class="jzBoxLink item-hover"  >  
								<img src="img/22.jpg" alt=" " class="img-responsive" /> 
							</a>    		
						</div>
					</div>
					<div class="col-md-3 gallery-grid">
						<div class="wpf-demo-4">  
							<a   class="jzBoxLink item-hover"  >  
								<img src="img/23.jpg" alt=" " class="img-responsive" /> 
							</a>    		
						</div>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- //welcome -->


<!-- subscribe section --> 
<div class="subscribe"> 
	<div class="container"> 
		<div class="w3-agileits-heading">
			<h3 class="title">Newsletter</h3> 
		</div>
		<div class="heading">
			<form action="#" method="post"> 
				<input type="email" name="email" placeholder="Enter your email..." required="">
				<input type="submit" value="Subscribe">
			</form>
		</div>
	</div>
</div>
<!-- //subscribe section -->

<?php include "footer.php"?>